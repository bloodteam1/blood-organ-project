    <nav class="navbar fixed-top navbar-toggleable-md navbar-inverse bg-inverse">
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarExample" aria-controls="navbarExample" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="container">
            <a class="navbar-brand" href="index.php">Blood & Organ Finder</a>
            <div class="collapse navbar-collapse" id="navbarExample">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="page.php?type=aboutus">About</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Blood Bank
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                          <a class="dropdown-item" href="bank_register.php">Blood Bank Register</a>
                          <a class="dropdown-item" href="bank_login.php">Blood Bank Login</a>
                          <a class="dropdown-item" href="portfolio-3-col.html">Available Blood At Bank</a>
                          
                        </div>
                      </li>
                      
                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Become a Donar
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                          <a class="dropdown-item" href="become-donar.php">Become a Blood Donar</a>
                          <a class="dropdown-item" href="become-organ-donar.php">Become a Organ Donor</a>
                        </div>
                      </li>
                      
                       <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownPortfolio" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Search
                        </a>
                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownPortfolio">
                          <a class="dropdown-item" href="search-donor.php">Blood Donar</a>
                          <a class="dropdown-item" href="search-donor.php">Blood Bank Donar</a>
                          <a class="dropdown-item" href="search-donor.php">Organ Donar</a>
                        </div>
                        
                      </li>
                    
                      <li class="nav-item">
                        <a class="nav-link" href="contact.php">Contact us</a>
                    </li>
                 
                 
                </ul>
            </div>
        </div>
    </nav>
