<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Blood &amp; Organ Donor Portal</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <link href="css/custom.css" rel="stylesheet"/>
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
    <style>
    .errorWrap {
        padding: 10px;
        margin: 0 0 20px 0;
        background: #fff;
        border-left: 4px solid #dd3d36;
        -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    }
    .succWrap{
        padding: 10px;
        margin: 0 0 20px 0;
        background: #fff;
        border-left: 4px solid #5cb85c;
        -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
        box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    }
    </style>
    <?php
    require_once "ebloodhelper.php";
    $helper = new EbloodHelper();
    $msg    = '';
    if($_POST)
    {
        $msg = $helper->checkAdminLogin();
    }
    ?>
    <script type="text/javascript">
    function validate_form()
    {
        var email = document.getElementById("email").value;
        var password = document.getElementById("password").value;
        
        if(email=='')
        {
            alert("Please Enter Email Address.");
            return false;
        }
        else if(validateEmail(email))
        {
            alert("Please Enter Valid Email Address.");
            return false;            
        }
        else if(password=='')
        {
            alert("Please Enter Password.");
            return false;
        }
        return true;
    }
    
    function validateEmail(email)
    {
        var atpos  = email.indexOf("@");   // The indexOf() method returns the position of the first occurrence of a specified value in a string. // Default value of start is 0  
        //alert(atpos);
        var dotpos = email.lastIndexOf(".");  // The lastIndexOf() method returns the position of the last occurrence of a specified value in a string. // Default value of start is 0  
        //alert(dotpos);
        
        if((atpos<1) || (dotpos<(atpos+2)) || (dotpos+2>=email.length))  
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    </script>
</head>

<body>

<?php include('includes/header.php');?>

    <!-- Page Content -->
    <div class="container container-minheight">

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3">Admin <small>Login</small></h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Admin Login</li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
        else if($msg){?><div class="succWrap"><strong>ERROR</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
        <!-- Content Row -->
        <form name="banklogin" method="post" onsubmit="return validate_form();">
            <div class="row">
                <div class="col-lg-4 mb-4">
                    <div class="font-italic">Email Id<span style="color:red">*</span></div>
                    <div><input type="email" id="email" name="email" class="form-control"></div>
                </div>
            </div>
            
            <div class="row">
                <div class="col-lg-4 mb-4">
                <div class="font-italic">Password<span style="color:red">*</span></div>
                <div><input type="password" id="password" name="password" class="form-control"></div>
                </div>
            </div> 
            <div class="row">
                <div class="col-lg-4 mb-4">
                <div><input type="submit" name="submit" class="btn btn-primary" value="Login" style="cursor:pointer"></div>
                </div>
            </div>
            
            
            
                    <!-- /.row -->
    </form>   
        <!-- /.row -->
</div>
  <?php include('includes/footer.php');?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
