<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Blood & Organ Finder | Become A Donar</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>
    <?php
    require_once "ebloodhelper.php";
    $helper = new EbloodHelper();
    ?>
</head>

<body>

<?php

include ('includes/header.php');

?>

    <!-- Page Content -->
    <div class="container container-minheight">

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3">Search Organ <small>Donor</small></h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Search Organ Donor</li>
        </ol>
        <?php
        if ($error)
        {
        
            ?>
            <div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error);?> </div>
            <?php
        
        } 
        else if ($msg)
        {
            ?>
            <div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg);?> </div>
            <?php
        }
        ?>
        <!-- Content Row -->
        <form name="donar" method="post">
        <div class="row">
            <div class="col-lg-4 mb-4">
                <div class="font-italic">Organ<span style="color:red">*</span> </div>
                <div>
                    <select name="organ" id="organ" class="form-control" required="">
                        <option value="">Select</option>
                        <option value="1">Heart</option>
                        <option value="2">Lung</option>
                        <option value="3">Kidney</option>
                        <option value="4">Liver</option>
                        <option value="5">Eye</option>
                    </select>
                </div>
            </div>
            
            
            <div class="col-lg-4 mb-4">
                <div class="font-italic">Location </div>
                <div><textarea class="form-control" name="location"></textarea></div>
            </div>
        
        </div>

<div class="row">
<div class="col-lg-4 mb-4">
<div><input type="submit" name="submit" class="btn btn-primary" value="submit" style="cursor:pointer"></div>
</div>
</div>
       <!-- /.row -->
</form>   

        <div class="row">
            <?php
                
                if (isset($_POST['submit']))
                {
                    $organ      = $_POST['organ'];
                    $location   = $_POST['location'];
                                
                    $db = new Database();
                    $db->open();
                    
                    $extraSql = '';
                    
                    if($organ !='')
                    {
                        $extraSql .= " AND organ = '".$organ."'";
                    }
                    
                    if($location !='')
                    {
                        $extraSql .= " AND address LIKE '%".$location."%'";
                    }
                    
                    $sql = "SELECT * FROM `organdonors` WHERE 1 ".$extraSql; 
                    $result = $db->query($sql);
                    
                    if($db->num_of_rows() > 0)
                    {
                        $organs_array = array('1'=>'Heart','2'=>'Lung','3'=>'Kidney','4'=>'Liver','5'=>'Eye',);
                        while($row = $db->fetcharray($result))
                        {
                            ?>
                            <div class="col-lg-4 col-sm-6 portfolio-item">
                                <div class="card h-100">
                                    <div class="card-block">
                                        <h3><a href="#">Organ: <?php echo $organs_array[$row['organ']];?></a></h3>
                                        <h4 class="card-title"><a href="#"><?php echo htmlentities($row['fullname']);?></a></h4>
                                        <p class="card-text"><b>Mobile No. / Email Id :</b> <?php echo htmlentities($row['mobile']);?> /
                                            <?php
                                            if ($row['email'] == "")
                                            {
                                                echo htmlentities(NA);
                                            } 
                                            else
                                            {
                                                echo htmlentities($row['email']);
                                            }
                                            ?>
                                        </p>
                                        <p class="card-text"><b>  Gender :</b> <?php echo htmlentities($row['gender']);?></p>
                                        <p class="card-text"><b> Age:</b> <?php echo htmlentities($row['age']);?></p>
                                        <p class="card-text"><b>Address :</b> <?php echo htmlentities($row['address']);?></p>
                
                                    </div>
                                </div>
                            </div>
                            <?php
                        }
                    } 
                    else
                    {
                        echo htmlentities("No Record Found");
                    }
                }
                
                ?>
          
 



        </div>



</div>
  <?php

include ('includes/footer.php');

?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
