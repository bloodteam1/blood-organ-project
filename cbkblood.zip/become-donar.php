<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Blood & Organ Finder | Become A Donar</title>
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/modern-business.css" rel="stylesheet">
    <style>
    .navbar-toggler {
        z-index: 1;
    }
    
    @media (max-width: 576px) {
        nav > .container {
            width: 100%;
        }
    }
    </style>
        <style>
    .errorWrap {
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #dd3d36;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
.succWrap{
    padding: 10px;
    margin: 0 0 20px 0;
    background: #fff;
    border-left: 4px solid #5cb85c;
    -webkit-box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
    box-shadow: 0 1px 1px 0 rgba(0,0,0,.1);
}
    </style>
    <script type="text/javascript">
    function validate_form()
    {
        var fullname     = document.getElementById("fullname").value;
        var mobileno     = document.getElementById("mobileno").value;
        var emailid      = document.getElementById("emailid").value;
        var age          = document.getElementById("age").value;
        var gender       = document.getElementById("gender").value;
        var bloodgroup   = document.getElementById("bloodgroup").value;
        var address      = document.getElementById("address").value;
        
        var validchar = /^[A-Z a-z]+$/;
        var validnum = /^[0-9]+$/;
        
        if(fullname=='')
        {
            alert("Please Enter Full Name.");
            return false;    
        }
        else if(!validchar.test(fullname))
        {
            alert("Full Name should not be numeric.");
            return false;
        }
        else if(mobileno=='')
        {
            alert("Please Enter Mobile Number.");
            return false;  
        }
        else if(isNaN(mobileno))
        {
            alert("Mobile Number should be numeric.");
            return false;  
        }
        else if(checkInternationalPhone(mobileno)==false)
        {
            alert("Please Enter a Valid Mobile Number");
    		return false;
        }
        else if(emailid=='')
        {
            alert("Please Enter Email Address.");
            return false;
        }
        else if(validateEmail(emailid))
        {
            alert("Please Enter Valid Email Address.");
            return false;   
        }
        else if(age=='')
        {
            alert("Please Enter Age.");
            return false;  
        }
        else if(!validnum.test(age))
        {
            alert("Age should be numeric.");
            return false;  
        }
        else if(gender=='')
        {
            alert("Please Select Gender.");
            return false;  
        }
        else if(bloodgroup=='')
        {
            alert("Please Select Blood Group.");
            return false;  
        }
        else if(address=='')
        {
            alert("Please Enter Address.");
            return false;  
        }
    }
    function validateEmail(email)
    {
        var atpos  = email.indexOf("@");   // The indexOf() method returns the position of the first occurrence of a specified value in a string. // Default value of start is 0  
        //alert(atpos);
        var dotpos = email.lastIndexOf(".");  // The lastIndexOf() method returns the position of the last occurrence of a specified value in a string. // Default value of start is 0  
        //alert(dotpos);
        
        if((atpos<1) || (dotpos<(atpos+2)) || (dotpos+2>=email.length))  
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    
    // Declaring required variables
    var digits = "0123456789";
    // non-digit characters which are allowed in phone numbers
    var phoneNumberDelimiters = "()- ";
    // characters which are allowed in international phone numbers
    // (a leading + is OK)
    var validWorldPhoneChars = phoneNumberDelimiters + "+";
    // Minimum no of digits in an international phone no.
    var minDigitsInIPhoneNumber = 10;
    
    function isInteger(s)
    {   var i;
        for (i = 0; i < s.length; i++)
        {   
            // Check that current character is number.
            var c = s.charAt(i);
            if (((c < "0") || (c > "9"))) return false;
        }
        // All characters are numbers.
        return true;
    }
    
    function trim(s)
    {   var i;
        var returnString = "";
        // Search through string's characters one by one.
        // If character is not a whitespace, append to returnString.
        for (i = 0; i < s.length; i++)
        {   
            // Check that current character isn't whitespace.
            var c = s.charAt(i);
            if (c != " ") returnString += c;
        }
        return returnString;
    }
    
    function stripCharsInBag(s, bag)
    {   var i;
        var returnString = "";
        // Search through string's characters one by one.
        // If character is not in bag, append to returnString.
        for (i = 0; i < s.length; i++)
        {   
            // Check that current character isn't whitespace.
            var c = s.charAt(i);
            if (bag.indexOf(c) == -1) returnString += c;
        }
        return returnString;
    }
    
    function checkInternationalPhone(strPhone){
        var bracket=3;
        strPhone=trim(strPhone);
        if(strPhone.indexOf("+")>1) return false;
        if(strPhone.indexOf("-")!=-1)bracket=bracket+1;
        if(strPhone.indexOf("(")!=-1 && strPhone.indexOf("(")>bracket)return false;
        var brchr=strPhone.indexOf("(");
        if(strPhone.indexOf("(")!=-1 && strPhone.charAt(brchr+2)!=")")return false;
        if(strPhone.indexOf("(")==-1 && strPhone.indexOf(")")!=-1)return false;
        s=stripCharsInBag(strPhone,validWorldPhoneChars);
        return (isInteger(s) && s.length >= minDigitsInIPhoneNumber);
    }    
    </script>
    <?php
    require_once "ebloodhelper.php";
    $helper = new EbloodHelper();
    
    if($_POST)
    {
        $msg = $helper->become_donor();
    }
    ?>

</head>

<body>

<?php include('includes/header.php');?>

    <!-- Page Content -->
    <div class="container container-minheight">

        <!-- Page Heading/Breadcrumbs -->
        <h1 class="mt-4 mb-3">Become a <small> Blood Donor</small></h1>

        <ol class="breadcrumb">
            <li class="breadcrumb-item">
                <a href="index.php">Home</a>
            </li>
            <li class="breadcrumb-item active">Become a Blood Donor</li>
        </ol>
            <?php if($error){?><div class="errorWrap"><strong>ERROR</strong>:<?php echo htmlentities($error); ?> </div><?php } 
            else if($msg){?><div class="succWrap"><strong>SUCCESS</strong>:<?php echo htmlentities($msg); ?> </div><?php }?>
            <!-- Content Row -->
            <form name="donar" method="post" onsubmit="return validate_form()">
        <div class="row">
        <div class="col-lg-4 mb-4">
        <div class="font-italic">Full Name<span style="color:red">*</span></div>
        <div><input type="text" id="fullname" name="fullname" class="form-control"></div>
        </div>
        <div class="col-lg-4 mb-4">
        <div class="font-italic">Mobile Number<span style="color:red">*</span></div>
        <div><input type="text" id="mobileno" name="mobileno" maxlength="10" class="form-control"></div>
        </div>
        <div class="col-lg-4 mb-4">
        <div class="font-italic">Email Id</div>
        <div><input type="text" id="emailid" name="emailid" class="form-control"></div>
        </div>
        </div>
        
        <div class="row">
        <div class="col-lg-4 mb-4">
        <div class="font-italic">Age<span style="color:red">*</span></div>
        <div><input type="text" id="age" name="age" class="form-control"></div>
        </div>
        
        
        <div class="col-lg-4 mb-4">
        <div class="font-italic">Gender<span style="color:red">*</span></div>
        <div><select id="gender" name="gender" class="form-control">
        <option value="">Select</option>
        <option value="Male">Male</option>
        <option value="Female">Female</option>
        </select>
        </div>
        </div>
        
        <div class="col-lg-4 mb-4">
        <div class="font-italic">Blood Group<span style="color:red">*</span> </div>
        <div><select id="bloodgroup" name="bloodgroup" class="form-control">
        <?php 
        echo $helper->getBloodGroupSelect();
        ?>
        </select>
        </div>
        </div>
        </div>
        
        
        <div class="row">
        <div class="col-lg-4 mb-4">
        <div class="font-italic">Address<span style="color:red">*</span></div>
        <div><textarea class="form-control" id="address" name="address"></textarea></div>
        </div>
        
        <div class="col-lg-8 mb-4">
        <div class="font-italic">Message</div>
        <div><textarea class="form-control" name="message"> </textarea></div>
        </div>
        </div>
        
        <div class="row">
        <div class="col-lg-4 mb-4">
        <div><input type="submit" name="submit" class="btn btn-primary" value="submit" style="cursor:pointer"></div>
        </div>
        
        
        
        </div>
        
        
        
                <!-- /.row -->
        </form>   
        <!-- /.row -->
</div>
  <?php include('includes/footer.php');?>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/tether/tether.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.min.js"></script>

</body>

</html>
