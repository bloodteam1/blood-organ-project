<?php
error_reporting(0);
session_start();
require_once "inc/config.php";
require_once "inc/dbhelper.php";
 
class EbloodHelper
{
    function checkAdminLogin()
    {
        $email=$_POST['email'];
        $password=$_POST['password'];
        
        $db = new Database();
        $db->open();
        $msg='';
        $sql="SELECT * FROM `admin` WHERE email='".$email."' AND password='".$password."'";
        
       //echo $sql;die;
        $result=$db->query($sql);
        $row=$db->fetchobject($result);
        
        if($row)
        {
            $_SESSION['fid']        = $row->id;
            $_SESSION['fusername']  = $row->username;
           	echo "<script>window.location = 'dashboard.php';</script>";
        }
        else
        {
            $msg='Sorry! Invalid Details.';
        }
        
        return $msg; 
    }
    
    function regUsers()
    {
        $username=$_POST['username'];
        $password=$_POST['password'];
        $name=$_POST['name'];
        $mobile=$_POST['mobile'];
        $email=$_POST['email'];
        $db = new Database();
        $db->open();
        $msg='';
        
        $sql    = "SELECT * FROM `users` WHERE `username` ='".$username."'";
        $result = $db->query($sql);
        
        if($db->num_of_rows($result))
        {
            $msg = 'Username already exists.';
            return $msg;
        }
        
        $sql="INSERT INTO `users` (`id`, `username`, `password`, `name`, `email`, `mobile`) 
              VALUES (NULL, '".$username."', '".$password."', '".$name."', '".$email."', '".$mobile."' );";
        $result=$db->query($sql);
        if($result)
        {
            $msg ='You successfully registered.'; 
        }
        else
        {
            $msg = 'Error Occured.';
        }
        return $msg; 
    }
    
    function regOrgandonar()
    {
        $fullname=$_POST['fullname'];
        $mobile=$_POST['mobile'];
        $email=$_POST['email'];
        $age=$_POST['age'];
        $gender=$_POST['gender'];
        $organ=$_POST['organ'];
        $address=$_POST['address'];
        
        $db = new Database();
        $db->open();
        $msg='';
        
        $sql="INSERT INTO `organdonors` (`id`, `fullname`, `mobile`, `email`, `age`, `gender`,`organ`,`address`) 
              VALUES (NULL, '".$fullname."', '".$mobile."', '".$email."', '".$age."', '".$gender."', '".$organ."', '".$address."');";
        $result=$db->query($sql);
        if($result)
        {
            $msg ='Registered successfully.'; 
        }
        else
        {
            $msg = 'Error Occured.';
        }
        return $msg; 
    }
    
    function getHomePageDonors()
    {
        $db = new Database();
        $db->open();
        
        $sql = "SELECT * FROM `tblblooddonars` WHERE status = 1 ORDER BY rand() limit 6"; 
        $result = $db->query($sql);

        $rows = array();
        if($db->num_of_rows())
        {
            while ($row = $db->fetcharray($result))
            {
                $rows[] = $row;
            }
        }
        
        return $rows;
    }
    
    function become_donor()
    {
        $db = new Database();
        $db->open();
        
        $fullname   = $_POST['fullname'];
        $mobile     = $_POST['mobileno'];
        $email      = $_POST['emailid'];
        $age        = $_POST['age'];
        $gender     = $_POST['gender'];
        $blodgroup  = $_POST['bloodgroup'];
        $address    = $_POST['address'];
        $message    = $_POST['message'];
        $status     = 1;
        
        $sql = "INSERT INTO  tblblooddonars(FullName,MobileNumber,EmailId,Age,Gender,BloodGroup,Address,Message,status) 
               VALUES('".$fullname."','".$mobile."','".$email."','".$age."','".$gender."','".$blodgroup."','".$address."','".$message."','".$status."')";
        $result=$db->query($sql);
        if($result)
        {
            $msg ='Registered successfully.'; 
        }
        else
        {
            $msg = 'Error Occured.';
        }
        return $msg; 
    }
    
    function getBloodGroupSelect()
    {
        $db = new Database();
        $db->open();
        
        $sql = "SELECT * FROM `tblbloodgroup`"; 
        $result = $db->query($sql);
        
        $html = '<option value="">Select Blood Group</option>';
        
        if($db->num_of_rows())
        {
            while ($row = $db->fetcharray($result))
            {
                $html .= '<option value="'.$row['BloodGroup'].'">'.$row['BloodGroup'].'</option>';
                
            }
        }
        return $html;
    }
    
    function getBloodGroupList()
    {
        $helper = new EbloodHelper();
        
        $db = new Database();
        $db->open();
        
        $sql = "SELECT * FROM `tblbloodgroup`"; 
        $result = $db->query($sql);
        
        ?>
        <table class="table table-bordered">
            <tr>
                <th>Blood Group</th>
                <th>Status</th>
            </tr>
        <?php
        
        if($db->num_of_rows())
        {
            $status_array = array("0"=>"Unavailable","1"=>"Available");
            while ($row = $db->fetcharray($result))
            {
                $status = $helper->checkBloodStatus($row['BloodGroup'], $_SESSION['fid']);
                ?>
                <tr>
                    <td><?php echo $row['BloodGroup'];?></td>
                    <td width="25%"><a href="bloodstatus.php?task=updateBloodStatus&bloodgroup=<?php echo urlencode($row['BloodGroup']);?>&bank_id=<?php echo $_SESSION['fid'];?>&status=<?php echo ($status) ? 0 : 1;?>"><?php echo $status_array[$status];?></a></td>
                </tr>
                <?php
                
            }
        }
        ?>
        </table>
        <?php
    }
    
 }

?>